// Package smithy adapts concrete AWS auth and signing types to the generic smithy versions.
package smithy
